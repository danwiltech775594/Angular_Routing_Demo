package com.example.blackboard.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.blackboard.models.Course;

public interface CourseRepository extends CrudRepository<Course, Integer>{
	

}
