package com.example.blackboard.models;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity(name = "coursetable")
public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)		
	Integer id;
	String authorName;
	String title;
	
	@OneToMany(mappedBy = "course")
	private List<Module> modules;
	public Course()	{		
	}
	
	public Course(Integer id, String authorName, String title) {
		this.id = id;
		this.authorName = authorName;
		this.title = title;
	}
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
